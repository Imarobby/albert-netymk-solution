import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;

public class SimpleWhiteBoard extends JFrame {
	private Image img;
	protected int lastX, lastY;

	protected void record(int x, int y) {
		lastX = x;
		lastY = y;
	}

	public SimpleWhiteBoard() {
		// getContentPane().setBackground(Color.black);
		setBackground(Color.black);
		// getContentPane().setForeground(Color.blue);
		// setForeground(Color.black);

		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				record(e.getX(), e.getY());
			}

		});

		addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseDragged(MouseEvent e) {
				getGraphics().drawLine(lastX, lastY, e.getX(), e.getY());
				record(e.getX(), e.getY());
			}
		});
		setVisible(true);
	}

	public void paint(Graphics g) {
		img = createImage(getWidth(), getHeight());
		img.getGraphics().drawImage(img, 0, 0, null);
		paint(g);
	}

	/*
	 * public void repaint() { img = createImage(getWidth(), getHeight());
	 * img.getGraphics().drawImage(img, 0, 0, null); repaint(); }
	 */
	public static void main(String[] args) {
		SwingConsole.run(SimpleWhiteBoard.class, 400, 400);
	}
}
